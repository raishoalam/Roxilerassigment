import React from 'react'

const Pagination = ({handlePrevPage, handleNextPage, currentPage}) => {
  return (
    <div>
      <button onClick={handlePrevPage} disabled={currentPage === 1}>
        Previous
      </button>
      <button onClick={handleNextPage}>Next</button>
    </div>
  )
}

export default Pagination
