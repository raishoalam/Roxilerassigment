import React from 'react'

const SearchBox = ({searchText, setSearchText}) => {
  return (
    <input
      type="text"
      value={searchText}
      onChange={e => setSearchText(e.target.value)}
      placeholder="Search Transaction"
    />
  )
}

export default SearchBox
