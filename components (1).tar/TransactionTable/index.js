import React, {useState, useEffect} from 'react'
import axios from 'axios'
import './index.css' // Import CSS file

const TransactionsTable = () => {
  const [transactions, setTransactions] = useState([])
  const [selectedMonth, setSelectedMonth] = useState('March')
  const [searchQuery, setSearchQuery] = useState('')
  const [currentPage, setCurrentPage] = useState(1)

  // Within the component function

  useEffect(() => {
    fetchTransactions()
  }, [])

  const fetchTransactions = async () => {
    try {
      const response = await axios.get('https://dummyjson.com/products')
      console.log('API Response:', response.data) // Log the response
      if (Array.isArray(response.data)) {
        setTransactions(response.data)
      } else {
        console.error('API response is not an array:', response.data)
      }
    } catch (error) {
      console.error('Error fetching transactions:', error)
    }
  }

  const filteredTransactions = transactions.filter(transaction => {
    console.log('Transaction:', transaction) // Log each transaction
    return (
      transaction.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      transaction.description
        .toLowerCase()
        .includes(searchQuery.toLowerCase()) ||
      transaction.price.toString().includes(searchQuery.toLowerCase())
    )
  })

  console.log('Filtered Transactions:', filteredTransactions) // Log the filtered transactions array

  const handleMonthChange = event => {
    setSelectedMonth(event.target.value)
    // You can fetch transactions for the selected month here
  }

  const handleSearchChange = event => {
    setSearchQuery(event.target.value)
  }

  const handleNextPage = () => {
    setCurrentPage(prevPage => prevPage + 1)
  }

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(prevPage => prevPage - 1)
    }
  }

  return (
    <div className="transactions-container">
      <select value={selectedMonth} onChange={handleMonthChange}>
        <option value="January">January</option>
        <option value="February">February</option>
        <option value="March">March</option>
        {/* Add other months */}
      </select>

      <input
        type="text"
        placeholder="Search transaction..."
        value={searchQuery}
        onChange={handleSearchChange}
      />

      <table className="transactions-table">
        {/* Table header */}
        <thead>
          <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Price</th>
            {/* Add other headers */}
          </tr>
        </thead>
        {/* Table body */}
        <tbody>
          {filteredTransactions.map(transaction => (
            <tr key={transaction.id}>
              <td>{transaction.title}</td>
              <td>{transaction.description}</td>
              <td>{transaction.price}</td>
              {/* Add other table data */}
            </tr>
          ))}
        </tbody>
      </table>

      <div className="pagination">
        <button onClick={handlePrevPage}>Previous</button>
        <button onClick={handleNextPage}>Next</button>
      </div>
    </div>
  )
}

export default TransactionsTable
